import React from 'react';
import { classes, compile, html, templates } from 'core/js/reactHelpers';

export default function OpenTextInput(props) {

  const {
    _allowedCharacters,
    _isComplete,
    _shouldShowModelAnswer,
    charactersLeft,
    modelAnswer,
    placeholder,
    remainingCharactersText,
    userAnswer
  } = props;

  return (
    <div className='component__inner opentextinput__inner'>
      <templates.header {...props} />

      <div className='component__widget opentextinput__widget'>

        <div
          className='opentextinput__count-characters'
          aria-live={_shouldShowModelAnswer || _isComplete ? "off" : "polite"}
        >
          {html(compile(charactersLeft + ' ' + remainingCharactersText))}
        </div>
        <div className='opentextinput__answer-container'>
          <textarea className='opentextinput__item-textbox'
            placeholder={placeholder}
            maxLength={_allowedCharacters}>{userAnswer}
          </textarea>
        </div>
        <div
          className={classes([
            'opentextinput__item-modelanswer',
            'opentextinput__item-textbox',
            !_shouldShowModelAnswer && 'u-display-none'
          ])}
        >
          {html(compile(modelAnswer))}
        </div>
        <div className='btn__container'></div>
      </div>

    </div>
  );
}
