import Adapt from 'core/js/adapt';
import components from 'core/js/components';
import OpenTextInputModel from './openTextInputModel';
import OpenTextInputView from './openTextInputView';

class OpenTextInput extends Backbone.Controller {

  initialize() {
    this.listenToOnce(Adapt, 'adapt:start', this.restoreQuestionStatusPolyfill);
  }

  /**
   * Spoor cannot store text input values and so the completion status of this component does not get
   * saved or restored properly. This function ensures that the question's completion status is
   * restored in a way that other extensions e.g. learning objectives can obtain accurate data for processing
   */
  restoreQuestionStatusPolyfill() {
    Adapt.components.each(component => {
      if (component.get('_component') !== 'openTextInput') return;
      if (!component.get('_isComplete')) return;
      // If the component is complete then it must be correct
      // _isInteractionComplete needs to be set to true so marking is restored correctly
      component.set({
        _isCorrect: true,
        _isInteractionComplete: true
      });
      // Add a manual trigger just in case any extensions listening for this change have already loaded
      component.trigger('change:_isComplete', component, true);
    });
  }
}

components.register('openTextInput', {
  view: OpenTextInputView,
  model: OpenTextInputModel
});

export default new OpenTextInput();
