const fs = require('fs');
const path = require('path');

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}
function writeJson(p, data) {
  fs.writeFileSync(p, JSON.stringify(data, null, 2), 'utf8');
}
function deepClone(o) {
  return JSON.parse(JSON.stringify(o));
}
function genId(seq){
  const h = (Date.now() + seq).toString(16);
  const filler = 'abcdef0123456789abcdef0123456789';
  return (h + filler).slice(0,24);
}

const root = 'src/course/en';
const coPath = path.join(root, 'contentObjects.json');
const aPath = path.join(root, 'articles.json');
const bPath = path.join(root, 'blocks.json');
const cPath = path.join(root, 'components.json');

const contentObjects = readJson(coPath);
const articles = readJson(aPath);
const blocks = readJson(bPath);
const components = readJson(cPath);

const menuB = contentObjects.find(o => o._type === 'menu' && /Anwenden/.test(o.title));
const menuC = contentObjects.find(o => o._type === 'menu' && /Bewerten/.test(o.title));
if (!menuB || !menuC) throw new Error('Menu B or C not found');

const pageTemplate = contentObjects.find(o => o._type === 'page');
const articleTemplate = articles[0];
const blockTemplate = blocks[0];
const tmplText = components.find(c => c._component === 'text');
const tmplMcq = components.find(c => c._component === 'mcq');
const tmplSlider = components.find(c => c._component === 'slider') || null;
const tmplAccordion = components.find(c => c._component === 'accordion') || null;

let tracking = blocks.reduce((m, b) => Math.max(m, b._trackingId||0), 0);
let seq = 1;

function newPage(parentId, title){
  const p = deepClone(pageTemplate);
  p.title = title; p.displayTitle = title;
  p._id = genId(seq++);
  p._parentId = parentId;
  if (p._graphic) { p._graphic.src = p._graphic.src || ''; p._graphic.alt = p._graphic.alt || ''; }
  return p;
}
function newArticle(parentId, title){
  const a = deepClone(articleTemplate);
  a.title = title; a.displayTitle = '';
  a._id = genId(seq++);
  a._parentId = parentId;
  if (a._articleBlockSlider) { a._articleBlockSlider._isEnabled = false; a._articleBlockSlider._hasTabs = false; }
  if (a._assessment && a._assessment._questions) { a._assessment._questions._resetType = 'hard'; }
  return a;
}
function newBlock(parentId, title){
  const b = deepClone(blockTemplate);
  b.title = title; b.displayTitle = title;
  b._id = genId(seq++);
  b._parentId = parentId;
  b._trackingId = ++tracking;
  if (b._pageLevelProgress) b._pageLevelProgress._isEnabled = false;
  return b;
}
function applyCommon(c){
  c._classes = c._classes || '';
  c._isOptional = false; c._isAvailable = true; c._isHidden = false; c._isVisible = true;
  c._isResetOnRevisit = c._isResetOnRevisit ?? 'false';
  if (c._pageLevelProgress) c._pageLevelProgress._isEnabled = true;
  if (c._tutor) { c._tutor._isInherited = true; }
  c._layout = c._layout || 'full';
  c.displayTitle = c.displayTitle || '';
}
function newTextComponent(parentId, title, body){
  const c = deepClone(tmplText);
  c._id = genId(seq++); c._parentId = parentId; c.title = title; c.body = body; c._component = 'text'; c._type = 'component';
  applyCommon(c);
  return c;
}
function newAccordionComponent(parentId, title, items){
  if (!tmplAccordion) return null;
  const c = deepClone(tmplAccordion);
  c._id = genId(seq++); c._parentId = parentId; c.title = title; c._component = 'accordion'; c._type = 'component';
  c._items = items.map(it => ({ title: it.title, body: it.body, _graphic: { alt: '', src: '', attribution: '' }, _classes: '' }));
  applyCommon(c);
  return c;
}
function newMcqComponent(parentId, title, instruction, items){
  const c = deepClone(tmplMcq);
  c._id = genId(seq++); c._parentId = parentId; c.title = title; c.body = ''; c.instruction = instruction; c.ariaQuestion = instruction; c._component = 'mcq'; c._type = 'component';
  c._items = items.map(it => ({ text: it.text, _shouldBeSelected: !!it.correct, _isPartlyCorrect: false, feedback: '', _score: 0 }));
  c._attempts = 1; c._canShowFeedback = true; c._canShowMarking = true; c._canShowModelAnswer = true; c._selectable = 1; c._hasItemScoring = false;
  applyCommon(c);
  return c;
}
function newSliderComponent(parentId, title, instruction, labelStart, labelEnd){
  if (!tmplSlider) return null;
  const c = deepClone(tmplSlider);
  c._id = genId(seq++); c._parentId = parentId; c.title = title; c.instruction = instruction; c._component = 'slider'; c._type = 'component';
  c.labelStart = labelStart; c.labelEnd = labelEnd; c._scaleStart = 1; c._scaleEnd = 5; c._scaleStep = 1; c._canShowFeedback = false;
  applyCommon(c);
  return c;
}

const lessons = [
  {
    pageTitle: 'Prompting-Strategien: präzise und wirksam',
    parentMenuId: menuB._id,
    articleTitle: 'Prompting-Strategien',
    blocks: [
      { t: 'Lernziele', comps: (pid)=> [
        newTextComponent(pid, 'Lernziele', '<ul><li>Ich kann den Unterschied zwischen offenen und fokussierten Prompts erklären.</li><li>Ich kann Rollen, Formatvorgaben und Kriterien gezielt einsetzen.</li><li>Ich kann komplexe Aufgaben in Schritte zerlegen (Chain-of-Thought).</li><li>Ich kann Prompts iterativ verbessern.</li></ul>')
      ]},
      { t: 'Einstieg & Vorwissen', comps: (pid)=> [
        newTextComponent(pid, 'Aktivierung', '<p>Notiere 2 Prompts, die du gestern genutzt hast. Waren sie offen oder fokussiert? Was war das Ziel?</p>'),
        newMcqComponent(pid, 'Begriffs-Check', 'Wähle die beste Aussage.', [
          {text:'Ein offener Prompt setzt klare Kriterien und Format.', correct:false},
          {text:'Ein fokussierter Prompt benennt Rolle, Ziel, Format und Kriterien.', correct:true},
          {text:'Offene Prompts sind immer besser als fokussierte.', correct:false}
        ])
      ]},
      { t: 'Grundlage', comps: (pid)=> [
        newTextComponent(pid, 'Grundlage', '<p>Ein guter Prompt definiert Kontext, Rolle, Ziel, Format und Bewertungskriterien. Iterationen mit Beispielen (Few-Shot) erhöhen die Zuverlässigkeit.</p>')
      ]},
      { t: 'Worked Example', comps: (pid)=> [
        newTextComponent(pid, 'Beispiel (schwach → stark)', '<table><thead><tr><th>Vorher</th><th>Nachher</th></tr></thead><tbody><tr><td>„Schreib was über Datenschutz.“</td><td>„Du bist Datenschutzbeauftragte:r. Erstelle eine 5-Punkte-Checkliste für KMU, jeweils mit Begründung und Quellen (EU-DSGVO). Format: Tabelle (Punkt, Begründung, Quelle).“</td></tr><tr><td>„Mach eine Präsentation.“</td><td>„Rolle: Executive Coach. Ziel: 5 Folien Pitch. Format: Folien-Gliederung mit Bullet Points. Kriterien: prägnant, ohne Jargon, 1 Beispiel je Folie.“</td></tr></tbody></table>')
      ]},
      { t: 'Fehlerbilder & Korrekturen', comps: (pid)=> [
        (tmplAccordion? newAccordionComponent(pid, 'Typische Fehler', [
          {title:'Unklare Rolle', body:'<p><b>Fix:</b> „Du bist … (z. B. Lektor:in, Controller:in).“</p>'},
          {title:'Keine Kriterien', body:'<p><b>Fix:</b> 3–5 prüfbare Kriterien (Ton, Zielgruppe, Länge, Quellen).</p>'},
          {title:'Vages Format', body:'<p><b>Fix:</b> Outputformate definieren (Tabelle, Stichpunkte, JSON-Schema).</p>'},
          {title:'Zu viele Ziele', body:'<p><b>Fix:</b> Aufgaben sequenzieren (Analyse → Entwurf → Prüfung → Überarbeitung).</p>'}
        ]) : null)
      ].filter(Boolean)},
      { t: 'Teilaspekt A: Rollen & Kriterien', comps: (pid)=> [
        newTextComponent(pid, 'Rollen & Kriterien', '<p>Weise eine Rolle zu (z. B. „Lektor:in“) und benenne 3–5 überprüfbare Kriterien (z. B. Ton, Zielgruppe, Länge, Quellenangaben).</p>'),
        (tmplAccordion? newAccordionComponent(pid, 'Advanced', [{title:'Beispiel-Kriterien', body:'<p>Ton: sachlich; Zielgruppe: Fachpublikum; Quellen: DOI; Format: Stichpunkte.</p>'}]) : null)
      ].filter(Boolean)},
      { t: 'Teilaspekt B: Strukturierung', comps: (pid)=> [
        newTextComponent(pid, 'Schrittweise Strukturierung', '<p>Zerlege Aufgaben in Teilschritte (Chain-of-Thought): Analyse → Entwurf → Prüfung → Überarbeitung. Nutze Platzhalter und Beispielantworten.</p>')
      ]},
      { t: 'Übung: Iteratives Prompting', comps: (pid)=> [
        newTextComponent(pid, '3-Runden-Übung', '<ol><li>Entwurf: Rolle, Ziel, Format, 3 Kriterien festlegen.</li><li>Test: Prompt ausführen, Output gegen Kriterien prüfen.</li><li>Verbesserung: 1–2 Kriterien schärfen, Beispiel hinzufügen.</li></ol><p><i>Abgabe:</i> Vorher/Nachher-Prompt + kurze Begründung der Änderungen.</p>')
      ]},
      { t: 'Interaktiv & Audit', comps: (pid)=> [
        newMcqComponent(pid, 'Was gehört in einen starken Prompt?', 'Wähle die beste Option.', [
          {text:'Vage Anweisung ohne Ziel', correct:false},
          {text:'Rolle, Ziel, Format und Kriterien', correct:true},
          {text:'Nur ein Beispiel ohne Kontext', correct:false}
        ]),
        newTextComponent(pid, 'Mini-Audit', '<ul><li>Klarer Zweck formuliert</li><li>Rolle festgelegt</li><li>Format definiert</li><li>3–5 Kriterien benannt</li><li>Beispiele/Few-Shot vorhanden</li></ul>'),
        newTextComponent(pid, 'Prompt-Redesign', '<p>Vorher: „Schreib was über Datenschutz.“<br/>Nachher: „Du bist Datenschutzbeauftragte:r. Erstelle eine 5-Punkte-Checkliste für KMU, jeweils mit Begründung und Quellen (EU-DSGVO).“</p>')
      ]},
      { t: 'Reflexion & Transfer', comps: (pid)=> [
        newTextComponent(pid, 'Exit-Ticket', '<p>Was ist dein wichtigstes Lernsignal heute? Wo setzt du morgen eine Kriterien-Liste ein?</p>'),
        newTextComponent(pid, 'Kompetenzraster', '<ul><li><b>Novize:</b> kennt Bausteine (Rolle, Ziel, Format, Kriterien)</li><li><b>Geübt:</b> baut konsistent fokussierte Prompts</li><li><b>Versiert:</b> iteriert mit Beispielen und Audit</li><li><b>Experte:</b> coacht andere und erstellt Checklisten</li></ul>')
      ]},
      { t: 'Zusammenfassung', comps: (pid)=> [
        newTextComponent(pid, 'Zusammenfassung', '<p>Kern: Rolle, Ziel, Format, Kriterien und Iteration führen zu besseren Ergebnissen.</p><p>Transferfrage: Wo kannst du morgen eine Aufgabe mit Kriterien prompten?</p>')
      ]}
    ]
  },

  {
    pageTitle: 'Kognitive Entlastung kritisch reflektieren',
    parentMenuId: menuC._id,
    articleTitle: 'Kognitive Entlastung & Kritik',
    blocks: [
      { t: 'Lernziele', comps: (pid)=> [
        newTextComponent(pid, 'Lernziele', '<ul><li>Ich kann kognitive Entlastung durch KI definieren.</li><li>Ich kann Risiken von Abhängigkeit und Trägheit benennen.</li><li>Ich kann Gegenmaßnahmen zur aktiven Kontrolle anwenden.</li></ul>')
      ]},
      { t: 'Einstieg', comps: (pid)=> [
        (tmplSlider? newSliderComponent(pid, 'Selbst-Einschätzung', 'Wie sehr verlässt du dich <i>im Durchschnitt</i> auf KI bei Wissensarbeit?', 'sehr', 'gar nicht')
          : newMcqComponent(pid, 'Selbst-Einschätzung', 'Wie sehr verlässt du dich im Durchschnitt auf KI?', [{text:'Sehr', correct:false},{text:'Mittel', correct:false},{text:'Wenig', correct:false}]))
      ]},
      { t: 'Grundlage', comps: (pid)=> [
        newTextComponent(pid, 'Grundlage', '<p>KI kann Routinearbeit reduzieren, birgt aber Risiken: Qualitätsabfall, Verlust eigener Expertise und Bestätigungsfehler. Metakognitive Strategien bleiben nötig.</p>')
      ]},
      { t: 'Fallvignette', comps: (pid)=> [
        newTextComponent(pid, 'Szenario', '<p>Eine Person übernimmt Textvorschläge ungeprüft. Nach Wochen sinken die eigenen Schreibfähigkeiten.</p>'),
        newMcqComponent(pid, 'Analyse', 'Welches Risiko ist hier am deutlichsten?', [
          {text:'Zeitgewinn ohne Nachteile', correct:false},
          {text:'Kompetenz-Erosion durch ungeprüfte Übernahme', correct:true},
          {text:'Zunahme der kreativen Vielfalt', correct:false}
        ])
      ]},
      { t: 'Teilaspekt A', comps: (pid)=> [
        newTextComponent(pid, 'Warnsignale', '<p>Übernahme ungeprüfter Vorschläge, fehlende Quellenprüfung, sinkende Aufmerksamkeit. Führe regelmäßige Ergebnis-Reviews durch.</p>')
      ]},
      { t: 'Teilaspekt B', comps: (pid)=> [
        newTextComponent(pid, 'Gegenmaßnahmen', '<p>„Human-in-the-Loop“, Checklisten, Quellenpflicht, Rotationsaufgaben ohne KI, Peer-Review.</p>'),
        (tmplAccordion? newAccordionComponent(pid, 'Advanced', [{title:'Metakognition', body:'<p>Selbstüberwachung, Ziel-/Kriteriendefinition, Reflexionsjournale.</p>'}]) : null)
      ].filter(Boolean)},
      { t: 'Übung: Kontrollschleifen', comps: (pid)=> [
        newTextComponent(pid, 'Red-Team/Blue-Team', '<ol><li><b>Blue:</b> Erstelle mit KI einen Entwurf.</li><li><b>Red:</b> Versuche, Schwächen zu finden (Quellen, Logik, Bias).</li><li><b>Blue:</b> Überarbeite und begründe Änderungen.</li></ol>')
      ]},
      { t: 'Interaktiv & Audit', comps: (pid)=> [
        (tmplSlider? newSliderComponent(pid, 'Selbst-Check', 'Wie stark verlässt du dich aktuell auf KI?', 'stark', 'gar nicht')
          : newMcqComponent(pid,'Selbst-Check','Wie stark verlässt du dich aktuell auf KI?', [{text:'Stark', correct:false},{text:'Moderat', correct:false},{text:'Kaum', correct:false}])),
        newTextComponent(pid, 'Mini-Audit', '<ul><li>Quellen geprüft</li><li>Eigene Begründung ergänzt</li><li>Gegenprobe durchgeführt</li><li>Peer-Review eingeholt</li></ul>'),
        newTextComponent(pid, 'Prompt-Redesign', '<p>Vorher: „Schreib mir eine Lösung.“<br/>Nachher: „Erkläre mir die Lösungsschritte, markiere Unsicherheiten und verweise auf Quellen (APA).“</p>')
      ]},
      { t: 'Reflexion & Commitment', comps: (pid)=> [
        newTextComponent(pid, 'Nächster Schritt', '<p>Welche eine Gegenmaßnahme setzt du in den nächsten 24 Stunden um? Notiere sie konkret.</p>')
      ]},
      { t: 'Zusammenfassung', comps: (pid)=> [
        newTextComponent(pid, 'Zusammenfassung', '<p>Kern: Entlastung ja, aber mit aktiver Kontrolle.</p><p>Transferfrage: Welche Gegenmaßnahme passt in deinen Workflow?</p>')
      ]}
    ]
  },

  {
    pageTitle: 'Transparenz: Black-Box, Provenienz & Governance',
    parentMenuId: menuC._id,
    articleTitle: 'Transparenz & Governance',
    blocks: [
      { t: 'Lernziele', comps: (pid)=> [
        newTextComponent(pid, 'Lernziele', '<ul><li>Ich kann Black-Box-Probleme erläutern.</li><li>Ich kann Datenprovenienz und Governance beschreiben.</li><li>Ich kann Nachvollziehbarkeit in Prompts und Workflows erhöhen.</li></ul>')
      ]},
      { t: 'Einstieg', comps: (pid)=> [
        newMcqComponent(pid, 'Begriffs-Check', 'Was beschreibt „Provenienz“ am treffendsten?', [
          {text:'Die Rechenleistung eines Modells', correct:false},
          {text:'Die Herkunft und Entstehungskette von Daten/Artefakten', correct:true},
          {text:'Die Marketing-Story eines Produkts', correct:false}
        ])
      ]},
      { t: 'Grundlage', comps: (pid)=> [
        newTextComponent(pid, 'Grundlage', '<p>Transparenz betrifft Datenherkunft, Verarbeitung, Modelle, Entscheidungen. Dokumentation und Offenlegung erhöhen Vertrauen und Auditierbarkeit.</p>')
      ]},
      { t: 'Vokabeln & Artefakte', comps: (pid)=> [
        (tmplAccordion? newAccordionComponent(pid, 'Glossar (kurz)', [
          {title:'Black-Box', body:'<p>Innere Entscheidungsgründe sind schwer einsehbar.</p>'},
          {title:'Datenprovenienz', body:'<p>Quelle, Lizenz, Verarbeitung, Versionen.</p>'},
          {title:'Modell-/Systemkarte', body:'<p>Kompakte Dokumentation von Zweck, Daten, Metriken, Risiken.</p>'},
          {title:'Änderungslog', body:'<p>Nachverfolgung von Updates und Effekten.</p>'}
        ]) : null),
        newTextComponent(pid, 'Mini-Vorlagen', '<table><thead><tr><th>Artefakt</th><th>Felder</th></tr></thead><tbody><tr><td>Quellenlog</td><td>Quelle, Lizenz, Datum, Link</td></tr><tr><td>Änderungslog</td><td>Version, Datum, Änderung, Impact</td></tr><tr><td>Evaluationsblatt</td><td>Metrik, Datensatz, Schwelle, Ergebnis</td></tr></tbody></table>')
      ].filter(Boolean)},
      { t: 'Teilaspekt A', comps: (pid)=> [
        newTextComponent(pid, 'Datenprovenienz', '<p>Quellenlog, Lizenzangaben, Versionierung. Nutze Modell-/Systemkarten und Referenzen.</p>')
      ]},
      { t: 'Teilaspekt B', comps: (pid)=> [
        newTextComponent(pid, 'Governance', '<p>Rollen, Verantwortlichkeiten, Freigaben, Incident-Prozesse, Löschkonzepte.</p>')
      ]},
      { t: 'Fallstudie', comps: (pid)=> [
        newMcqComponent(pid, 'Best-Practice wählen', 'Welche Maßnahme erhöht Nachvollziehbarkeit am stärksten?', [
          {text:'Keine Dokumentation', correct:false},
          {text:'System-/Modellkarten mit Datenhinweisen', correct:true},
          {text:'Nur Marketing-FAQs', correct:false}
        ])
      ]},
      { t: 'Interaktiv & Audit', comps: (pid)=> [
        newTextComponent(pid, 'Mini-Audit', '<ul><li>Quellennachweis vorhanden</li><li>Lizenzen dokumentiert</li><li>Version/Datum gespeichert</li><li>Änderungslog geführt</li></ul>'),
        newTextComponent(pid, 'Prompt-Redesign', '<p>Vorher: „Erkläre das Modell.“<br/>Nachher: „Fasse in 5 Stichpunkten zusammen: Trainingsdaten (Quelle/Lizenz), Evaluationsdaten, Limitierungen, bekannte Risiken; verlinke auf Systemkarte.“</p>')
      ]},
      { t: 'Zusammenfassung', comps: (pid)=> [
        newTextComponent(pid, 'Zusammenfassung', '<p>Kern: Transparenz entsteht durch durchgängige Dokumentation.</p><p>Transferfrage: Welche Nachweise fehlen dir noch?</p>')
      ]}
    ]
  },

  {
    pageTitle: 'Verzerrungen: Repräsentation, toxische Inhalte, Confirmation Bias',
    parentMenuId: menuC._id,
    articleTitle: 'Verzerrungen & Bias',
    blocks: [
      { t: 'Lernziele', comps: (pid)=> [
        newTextComponent(pid, 'Lernziele', '<ul><li>Ich kann Bias-Arten unterscheiden.</li><li>Ich kann toxische Inhalte erkennen und mitigieren.</li><li>Ich kann Confirmation Bias aktiv entgegenwirken.</li></ul>')
      ]},
      { t: 'Einstieg', comps: (pid)=> [
        newMcqComponent(pid, 'Begriffs-Check', 'Was ist ein Anzeichen für Confirmation Bias?', [
          {text:'Suche nach gegenteiligen Belegen', correct:false},
          {text:'Nur Bestätigendes berücksichtigen', correct:true},
          {text:'Zufällige Auswahl von Quellen', correct:false}
        ])
      ]},
      { t: 'Grundlage', comps: (pid)=> [
        newTextComponent(pid, 'Grundlage', '<p>Bias kann aus Daten, Modellen oder Nutzung entstehen. Mitigation erfordert kombinierte Maßnahmen.</p>')
      ]},
      { t: 'Fehlerbilder', comps: (pid)=> [
        (tmplAccordion? newAccordionComponent(pid, 'Typen von Bias', [
          {title:'Repräsentations-Bias', body:'<p>Unausgewogene Datensätze bevorzugen Gruppen.</p>'},
          {title:'Labeling-Bias', body:'<p>Subjektive/uneinheitliche Annotationspraxis.</p>'},
          {title:'Measurement-Bias', body:'<p>Messfehler oder ungeeignete Proxies.</p>'}
        ]) : null)
      ].filter(Boolean)},
      { t: 'Teilaspekt A', comps: (pid)=> [
        newTextComponent(pid, 'Repräsentations-Bias', '<p>Unausgewogene Datensätze bevorzugen bestimmte Gruppen. Nutze Ausgleichsstrategien und Fairness-Metriken.</p>')
      ]},
      { t: 'Teilaspekt B', comps: (pid)=> [
        newTextComponent(pid, 'Toxische Inhalte & Confirmation Bias', '<p>Moderationsfilter, Quellenvielfalt, Gegenfragen („Devil’s Advocate“), diverse Testfälle.</p>')
      ]},
      { t: 'Übung: Devil’s Advocate', comps: (pid)=> [
        newTextComponent(pid, 'Gegenprobe', '<ol><li>Formuliere eine Gegenthese zu deiner Annahme.</li><li>Recherchiere mind. 2 Gegenbelege.</li><li>Bewerte beide Seiten mit einer kurzen Evidenz-Notiz.</li></ol>')
      ]},
      { t: 'Interaktiv & Audit', comps: (pid)=> [
        newTextComponent(pid, 'Mini-Audit', '<ul><li>Gegenprobe mit Gegenthese</li><li>Mehrere Quellen</li><li>Fairness-Metriken geprüft</li><li>Moderationsfilter aktiv</li></ul>'),
        newTextComponent(pid, 'Prompt-Redesign', '<p>Vorher: „Beweise meine These.“<br/>Nachher: „Lege Pro und Contra dar, nenne Unsicherheiten und bewerte Quellenqualität (Checkliste).“</p>')
      ]},
      { t: 'Reflexion', comps: (pid)=> [
        (tmplSlider? newSliderComponent(pid, 'Bias-Achtsamkeit', 'Wie gut erkennst du aktuell eigene Verzerrungen?', 'sehr gut', 'kaum')
          : newMcqComponent(pid, 'Bias-Achtsamkeit', 'Wie gut erkennst du aktuell eigene Verzerrungen?', [{text:'Sehr gut', correct:false},{text:'Mittel', correct:false},{text:'Kaum', correct:false}]))
      ]},
      { t: 'Zusammenfassung', comps: (pid)=> [
        newTextComponent(pid, 'Zusammenfassung', '<p>Kern: Bias entsteht schnell – Gegenmaßnahmen müssen systematisch sein.</p><p>Transferfrage: Wo testest du heute aktiv Gegenbeispiele?</p>')
      ]}
    ]
  },

  {
    pageTitle: 'EU AI Act: Pflichten für Hochrisiko und generative/GPAI',
    parentMenuId: menuC._id,
    articleTitle: 'EU AI Act: Pflichten (M5)',
    blocks: [
      { t: 'Lernziele', comps: (pid)=> [
        newTextComponent(pid, 'Lernziele', '<ul><li>Ich kann Pflichten des EU AI Act benennen.</li><li>Ich kann Anforderungen für Hochrisiko-Systeme und GPAI unterscheiden.</li><li>Ich kann Umsetzungsmaßnahmen in Projekten planen.</li></ul>')
      ]},
      { t: 'Einstieg', comps: (pid)=> [
        newMcqComponent(pid, 'Einordnung', 'Welche Aussage passt eher zu Hochrisiko-Systemen?', [
          {text:'Keine Dokumentation nötig', correct:false},
          {text:'Konformitätsbewertung mit definierten Pflichten', correct:true},
          {text:'Nur freiwillige Selbstverpflichtung', correct:false}
        ])
      ]},
      { t: 'Grundlage', comps: (pid)=> [
        newTextComponent(pid, 'Grundlage', '<p>Der EU AI Act differenziert nach Risiko. Hochrisiko-Systeme und GPAI/Generative Modelle haben klare Pflichten entlang des Lebenszyklus.</p><p><i>Hinweis:</i> Pflichten treten phasenweise in Kraft. Prüfe Übergangsfristen in deiner Organisation.</p>')
      ]},
      { t: 'Teilaspekt A: Hochrisiko', comps: (pid)=> [
        newTextComponent(pid, 'Pflichten Hochrisiko', '<ul><li>Datenqualität: relevante, repräsentative, fehlerarme Datensätze</li><li>Risikomanagement: kontinuierlich, dokumentiert</li><li>Dokumentation/Technische Doku</li><li>Logging/Aufzeichnungen</li><li>Transparenzhinweise</li><li>Menschliche Aufsicht</li><li>Robustheit, Genauigkeit, Cybersicherheit</li><li>Konformitätsbewertung, CE</li></ul>')
      ]},
      { t: 'Teilaspekt B: GPAI/generative', comps: (pid)=> [
        newTextComponent(pid, 'Pflichten Generative/GPAI', '<ul><li>Urheberrechts-Schutzmaßnahmen (z. B. TDM-Opt-out-Beachtung)</li><li>Trainings-/Datenhinweise (Zusammenfassung der verwendeten Quellen)</li><li>System-/Modellkarten</li><li>Evaluation, Monitoring, Incident-Reporting</li></ul>')
      ]},
      { t: 'Rollen & Verantwortlichkeiten', comps: (pid)=> [
        newTextComponent(pid, 'Rollenmatrix (vereinfacht)', '<table><thead><tr><th>Rolle</th><th>Kernaufgabe</th></tr></thead><tbody><tr><td>Anbieter (Provider)</td><td>Entwicklung, Konformität, Doku</td></tr><tr><td>Inverkehrbringer/Anwender (Deployer)</td><td>Einsatz, Monitoring, Risiko-Kontrollen</td></tr><tr><td>Importeur/Händler</td><td>Nachweise prüfen, Weitergabe von Infos</td></tr></tbody></table>')
      ]},
      { t: 'Fall & Entscheidung', comps: (pid)=> [
        newMcqComponent(pid, 'Szenario', 'Ein Unternehmen will ein KI-Modul für Bewerbungsranking einsetzen. Welche Pflicht ist zentral?', [
          {text:'Nur Marketing-Transparenz', correct:false},
          {text:'Konformitätsbewertung inkl. QM-System', correct:true},
          {text:'Keine Pflichten, da internes Tool', correct:false}
        ])
      ]},
      { t: 'Interaktiv & Audit', comps: (pid)=> [
        newTextComponent(pid, 'Mini-Audit', '<ul><li>Risikomanagementplan vorhanden</li><li>Datenqualität belegt</li><li>Technische Doku vollständig</li><li>Logging implementiert</li><li>Aufsicht geregelt</li><li>Konformitätsweg dokumentiert</li></ul>'),
        newTextComponent(pid, 'Prompt-Redesign', '<p>Vorher: „Ist unser System compliant?“<br/>Nachher: „Liste für unser KI-System die Nachweise je Pflicht (Datenqualität, Risiko, Doku, Logging, Transparenz, Aufsicht, Robustheit/Genauigkeit/Cybersicherheit, Konformitätsbewertung) mit Status und Lücken auf.“</p>')
      ]},
      { t: 'Umsetzungsfahrplan', comps: (pid)=> [
        newTextComponent(pid, '30/60/90-Tage-Plan', '<ul><li><b>30:</b> Gap-Analyse, Rollen klären, Artefakt-Vorlagen anlegen</li><li><b>60:</b> Prozesse pilotieren (Logging, Review), Doku befüllen</li><li><b>90:</b> Interne Audits, Schulung, Freigabepfade</li></ul>')
      ]},
      { t: 'Zusammenfassung', comps: (pid)=> [
        newTextComponent(pid, 'Zusammenfassung', '<p>Kern: Pflichten sind überprüfbar und dokumentationsbasiert.</p><p>Transferfrage: Welche Nachweise fehlen euch noch?</p>')
      ]}
    ]
  }
];

for (const lesson of lessons) {
  const page = newPage(lesson.parentMenuId, lesson.pageTitle);
  const article = newArticle(page._id, lesson.articleTitle);
  contentObjects.push(page);
  articles.push(article);
  for (const blk of lesson.blocks) {
    const block = newBlock(article._id, blk.t);
    blocks.push(block);
    for (const comp of blk.comps(block._id)) {
      components.push(comp);
    }
  }
}

writeJson(coPath, contentObjects);
writeJson(aPath, articles);
writeJson(bPath, blocks);
writeJson(cPath, components);

console.log('done', { co: contentObjects.length, a: articles.length, b: blocks.length, c: components.length });

